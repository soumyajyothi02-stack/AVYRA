# AVYRA Android completion patch

This patch supplies the Android Gradle/Kotlin/resource files missing from the uploaded repository and updates Flutter package/app branding to AVYRA.

## Apply it safely

1. Extract the original `AVYRA-main.zip`.
2. Extract this patch ZIP into a separate folder.
3. Copy the patch's `flutter_app` folder contents into the original repository's `flutter_app` folder, allowing files to be replaced. Do not replace existing `lib/screens`, `lib/services`, or other source folders; replace only `lib/main.dart`.
4. Open PowerShell in the original repository's `flutter_app` folder.
5. Run:

```powershell
flutter create --platforms=android --org com.avyra --project-name avyra .
flutter pub get
flutter analyze
flutter run
```

The `flutter create` command generates Flutter SDK-version-specific wrapper scripts and the Gradle wrapper JAR, which are intentionally not bundled here. It may refresh generated Android scaffolding; if it overwrites the AVYRA files, copy the patch's `android` folder into place again.

## Notes

- Android application ID: `com.avyra.app`
- Display name: `AVYRA`
- Minimum Android SDK: 23
- Release builds currently use debug signing only. Configure a private release keystore before publishing.
- This patch completes the Android project scaffold; it does not certify that every screen, API, Firebase feature, or ML workflow works. Run the commands above and resolve any compile-time issues before submission.
