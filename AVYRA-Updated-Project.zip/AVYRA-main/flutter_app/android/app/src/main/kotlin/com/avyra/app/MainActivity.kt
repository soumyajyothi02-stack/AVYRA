package com.avyra.app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
